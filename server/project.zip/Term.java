// Mohamed Farih
// CSC 464
// File: Term.java
// 

import java.util.*;


public class Term
{
	//variaables that will be used.
	private int exponent;
	private double coefficient;
	
	//constructor
	public Term(double coeff, int exp)
	{
		exponent = exp;
		coefficient = coeff;
	}
	
	public Term(Term t)
	{	
		exponent = t.exponent;
		coefficient = t.coefficient;
	}
	public double getCoefficient()
	{
		return coefficient;
	}
	public int getExponent()
	{
		return exponent;
	}
	public void setCoefficient(double coeff)
	{
		coefficient = coeff;
	}
	public void setExponent(int exp)
	{
		exponent = exp;
	}
	public String strprint()
	{
	  String str = new String(this.getCoefficient()	+ "x^" + this.getExponent());
	  return str;
	}
	
	//evaluating the term from the value given for x
	public double evaluate(double value)
	{
		//double value;
		double result;
		//System.out.print("Enter a value for x: ");
		//value = user_input.next();
		result = (Math.pow(value, getExponent()) * getCoefficient());
		return result;
	}
	
	//multiply coefficients of the term and set the new coefficient
	public double multiply(double factor)
	{
		//System.out.print("Enter a factor you want to multiply the coefficients by ");
		//factor = user_input.next();
		factor *= getCoefficient();
		//setCoefficient(factor);
		setCoefficient(factor);
		return getCoefficient();
	}
	//isgreater method, check the exponents of new term f
	public boolean isGreater(Term x)
	{
		 if(this.getExponent() > x.getExponent())
			 return true;
		 else
			 return false;
	}
	
	//lessthan method
	public boolean lessThan(Term x )
	{
		if(this.getExponent() < x.getExponent())
			return true;
		else
			return false;
	}
	//equal too 
	public boolean equalTo(Term rhs)
	{
		if (this.getExponent() == rhs.getExponent())
			return true;
		else
			return false;
	
	}
	//not equal to
	public boolean notEqual(Term rhs)
	{
		if(this.getExponent() != rhs.getExponent())
			return true;
		else 
			return false;
	}
	// add coefficient to equal exponent terms
	public Term plusEquals(Term rv)
	{
		this.setCoefficient(this.getCoefficient() + rv.getCoefficient());
		return this;
	}
	
}
