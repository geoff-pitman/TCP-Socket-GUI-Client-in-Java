import java.util.Vector;
import java.util.*;
import java.util.Iterator;
import java.util.Scanner; 

// Mohamed Farih
// CSC 464
// File: Term.java
// 


public class Polynomial extends Vector
{
	private static Vector<Term> list;
	private Iterator<Term> it;
	Scanner userInput = new Scanner(System.in);
	
	public Polynomial()
	{
		list = new Vector<Term>();
		Term t1 = new Term(5,2);
		Term t2 = new Term(4,3);
		Term t3 = new Term(5, 6);
		list.add(t1);
		list.add(t2);
		list.add(t3);
	}
	/*
	public Term[] getAr(Polynomial this)
	{
		Term[] anarray = new Term[this.size()];
		int i =0;
		while( i < this.size())
		{
			anarray[i] = new Term(this.list.elementAt(i));
			System.out.println(anarray[i].getCoefficient() + anarray[i].getExponent());
		}
		
		return anarray;
	}
	*/
	//mutator?
	public void multiply(double factor)
	{
		Iterator<Term> it = this.list.iterator();
		
		while(it.hasNext())
			it.next().multiply(factor);
		
		/*
         Polynomial retval = new Polynomial();
		for(int i = 0; i < this.size(); i++)
		{
			arr[i].multiply(factor);
			retval.list.addElement(arr[i]);
		}
		
		return retval; 
		*/
	}
	
	public void evaluate(double value)
	{
		Iterator<Term> it = this.list.iterator();
		double res =0;
		while(it.hasNext())
		{
			res += it.next().evaluate(value);
		}
		
		System.out.println(res);
		
	}
	public void printlist()
	{
		/*
		Iterator<Term> it = this.list.iterator();
		
		while(it.hasNext())
		{
			System.out.println(it.next().strprint());
		}
		*/
		for (int i = 0; i < list.size(); i++)
		{
			System.out.println(list.elementAt(i).strprint());
			
		}

		
		/*
		for(int i = 0; i < this.size(); i++)
		{
			arr[i].multiply(factor);
			retval.list.addElement(arr[i]);
		}
		
		return retval;
		*/
	}
	
	
	public boolean addt(Term elt)
	{
		if (elt.getExponent() < 0)
			return false;
		else if (list.size() == 0)
		{
			list.add(elt);
			return true;
		}
		int idx = 0;
		while(idx < list.size())
		{
			if(list.elementAt(idx).getExponent() == elt.getExponent())
			{	
				list.elementAt(idx).setCoefficient(list.elementAt(idx).getCoefficient()+ elt.getCoefficient());
				//System.out.println(list.elementAt(idx).getCoefficient() + "x^" + list.elementAt(idx).getExponent());
				return true;
				//System.out.println("add element when exponentsare the same");
			}
			else if(list.elementAt(idx).getExponent() != elt.getExponent())
			{
				list.add(elt);
				return true;
			}
		   idx++;
		}
		return true;
	}
	/*
	public void orderedInsert(Term elt)
	{
		if(list.size() == 0)
			list.add(elt);
		else if(list.size() > 0)
		{
			// Check to see if it's equal. if it is add them
			// if it's not, then iterate from the beginning of the list
			// find the first element that is bigger than it, and place it IN FRONT of it
			// meaning, at a lower index.  If no element is bigger, inset it into rear.
			boolean flag = true;
			
			for(int idx = 0; idx < list.size(); idx++)
			{
				if(list.elementAt(idx).getExponent() == elt.getExponent())
				{	
					list.elementAt(idx).setCoefficient(list.elementAt(idx).getCoefficient()+ elt.getCoefficient());
					//System.out.println(list.elementAt(idx).getCoefficient() + "x^" + list.elementAt(idx).getExponent());

					//System.out.println("add element when exponentsare the same");
					flag = false;
				}
			}
			if (flag)
			{
				for(int idx = 0; idx < list.size(); idx++)
				{
					if (elt.getExponent() > list.elementAt(idx).getExponent())
					{
						list.add(elt);
					}
					else
					{
						Term ter = new Term(list.elementAt(idx).getCoefficient(), list.elementAt(idx).getExponent());
						list.elementAt(idx).setCoefficient(elt.getCoefficient());
						list.elementAt(idx).setExponent(elt.getExponent());
						list.add(ter);  
					}
				}
			}
		}
	}

		while (idx < list.size()) 
		{
			if (elt.getExponent() > list.elementAt(idx).getExponent())
			{
				list.add(elt);
				System.out.println("")
			}
			else
			{
				Term temp1 = new Term(elt);
				Term temp2 = new Term(list.elementAt(idx));
				list.add(temp2);
				list.elementAt(idx).setCoefficient(elt.getCoefficient());
				list.elementAt(idx).setCoefficient(elt.getExponent());
			}
		}
		return true;
		*/
	
	//remove term
	public boolean removeTerm(Term input)
	{
		System.out.println("what is the exponent of the term you are removing?");
		
		if (list.size() == 0)
			return false;
		for(int index = 0; index < list.size(); index++)
		{
			if(input.getExponent() == list.elementAt(index).getExponent())
			{
				list.remove(index);
				System.out.println("the term" + input +  "is removed");
				return true;
			} 	
			else
			{
				System.out.println("The terms exponent is not in the list\n");
				return false;
			}
		}
		return true;
	}
	
	//change components of term
	public void changeTerm(Term cTerm)
	{
	
		boolean flag = false;
		System.out.println("What Term would you like to change? Choose that terms exponent");
	    int inp = userInput.nextInt();
		while(!flag)
		{
			for(int indx = 0; indx < list.size(); indx++)
			{
				if(inp == list.elementAt(indx).getExponent())
				{
					System.out.println("What would you like to change in the term? (C for coefficient, E for exponent)");
					//Scanner userInput = new Scanner(System.in);
					String coeff = userInput.next();
					if(coeff.equals("c")) //string or character comparison
					{
						System.out.println("What is the new value of the coefficient?");
						double co = userInput.nextDouble(); //validate this
						list.elementAt(indx).setCoefficient(co);
						flag = true;
							//needs to not remove the term rather change the terms coefficient and keep it in the list rather than just adding a new term
					}   
					else if(coeff.equals("e"))
					{
						System.out.println("What is the new value of the exponent?");
						int exp = userInput.nextInt();
						list.elementAt(indx).setExponent(exp);
						//needs to not remove the term rather change the terms exponent and keep it in the list rather than just adding a new term. 
						//if exp is changed 
						flag = true;
					}
					else
						System.out.println("Enter valid input! \n");
				}
			}
		}
	}
}

