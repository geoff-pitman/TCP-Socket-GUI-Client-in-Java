import java.io.*;
import java.util.*;
import java.lang.*;

//Mohamed Farih
//CSC 464
//Dr. Spiegel
//Menu page 

public class Menu
{
	private static Polynomial list = new Polynomial();
	private static Vector<Term> Tlist = new Vector<Term>();
	
	public static void main(String[] args)
	{
		//DataReader reader = new DataReader();
		File file = new File("src/A.txt");
		Scanner readFile;
		try {
			readFile = new Scanner(file);
			Term ter;
			for (int i=0; readFile.hasNextLine(); i++)
			{

				ter = new Term(readFile.nextDouble(), readFile.nextInt());	
				list.addt(ter);
				//Menu.mainMenu();
			}
			readFile.close();
			
			list.printlist();
			Menu.mainMenu();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	   }

	
	public static void mainMenu()
	{
		
		//
		
		String quit = "n";
		Polynomial cTerm = new Polynomial();
	 
	
		System.out.println("Choose from the following:\n");
		System.out.println("E - Evaluate the polynomial ");
		System.out.println("M - Multiply the polynomial");
		System.out.println("A - Add a term");
		System.out.println("R - Remove a Term");
		System.out.println("C - Change a term");
		System.out.println("\nEnter your menu choice: ");
		Scanner userInput = new Scanner(System.in);
		String choice = userInput.nextLine();
		
		switch(choice)
		{
			case "E":
			case "e":
					
					break;
			case "M":
			case "m":
				break;
			case "A":
			case "a":
				break;
			case "R":
			case "r":
				break;
			case "C": 
			case "c":
				break;
			case "q":
			case "Q":
				break;
			default:
				System.out.println("Invalid choice.");
		}
		//finally;
		//System.out.print("Would you like to quit y/n?");
		//quit = userInput.nextLine().toLowerCase();	

	}
	public static void evaluatePoly(double input)
	{
		Scanner uInput = new Scanner(System.in);
		System.out.println("what is the value for x?");
		input = uInput.nextDouble();
		list.evaluate(input);
	}
	public static void multiplyPoly(double val)
	{
		Scanner uInput = new Scanner(System.in);
		System.out.println("what do you want to multiply the coefficients by?");
		val = uInput.nextDouble();
		list.multiply(val);
		list.printlist();
	}
	public static void addPoly(Term valA)
	{
		Scanner uInput = new Scanner(System.in);
		double coefficients;
		int exponent;
		System.out.println("What is the coefficient value?");
		coefficients = uInput.nextDouble();
		System.out.println("What is the exponent value?");
		exponent = uInput.nextInt();
		valA = new Term(coefficients, exponent);
		list.addt(valA);
		list.printlist();
	}
	public static void removePoly(Term valR)
	{
		Scanner uInput = new Scanner(System.in);
		list.printlist();
		int exp;
		System.out.println("What is the exponent of the term you would like to remove?");
		exp = uInput.nextInt();
		System.out.println("The exp was inputted");
		valR = new Term(0.0, exp);
		list.removeTerm(valR);
		System.out.println("The term is removed");
		list.printlist();
	}
	public static void changePoly(Term valC)
	{
		Scanner uInput = new Scanner(System.in);
		list.printlist();
		double coeff;
		int expon;
		System.out.println("What is the new coefficient value?");
		coeff = uInput.nextDouble();
		System.out.println("What is the new exponent value?");
		expon = uInput.nextInt();
		valC = new Term(coeff, expon);
		list.changeTerm(valC);
		list.printlist();
	}
	public static void checkQuit(String userChoice)
	{
		System.out.println("Do you really want to quit?");
		if(userChoice == "y" || userChoice == "Y")
		{
			userChoice = "x";
			return;
		}
		else 
		{
			return;
		}
	}
}